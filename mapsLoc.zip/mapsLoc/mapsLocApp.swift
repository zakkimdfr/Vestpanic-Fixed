//
//  mapsLocApp.swift
//  mapsLoc
//
//  Created by Vargo Alfonso on 30/06/22.
//

import SwiftUI

@main
struct mapsLocApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            BioAuthApp()
        }
    }
}
